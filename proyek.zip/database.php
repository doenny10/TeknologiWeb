<?php
session_start();
	$con=mysqli_connect("localhost", "root", "", "tekweb");

//------------------- REGISTER -------------------------------------------------------------------
	if(isset($_POST['insert'])){
		$name=$_POST["name"];
		$username=$_POST["username"];
		$password=$_POST["password"];
		$email=$_POST["email"];
		$address=$_POST["address"];
		$gender=$_POST["gender"];

		if($name == ""){
			$_SESSION['user'] = "";
			$_SESSION['username'] = $usernamename;
			$_SESSION['pass'] = $password;
			$_SESSION['email'] = $email;
			$_SESSION['address'] = $address;
			$_SESSION['gender'] = $gender;
			header("Location: register.php");
		}
		else if($username == ""){
			$_SESSION['username'] = "";
			$_SESSION['user'] = $name;
			$_SESSION['pass'] = $password;
			$_SESSION['email'] = $email;
			$_SESSION['address'] = $address;
			$_SESSION['gender'] = $gender;
			header("Location: register.php");
		}
		elseif ($password == "") {
			$_SESSION['pass'] = "";
			$_SESSION['username'] = $username;
			$_SESSION['user'] = $name;
			$_SESSION['email'] = $email;
			$_SESSION['address'] = $address;
			$_SESSION['gender'] = $gender;
			header("Location: register.php");
		}
		elseif ($email == ""){
			$_SESSION['email'] = "";
			$_SESSION['username'] = $username;
			$_SESSION['user'] = $name;
			$_SESSION['pass'] = $password;
			$_SESSION['address'] = $address;
			$_SESSION['gender'] = $gender;
			header("Location: register.php");
		}
		elseif ($address == "") {
			$_SESSION['address'] = "";
			$_SESSION['username'] = $username;
			$_SESSION['user'] = $name;
			$_SESSION['pass'] = $password;
			$_SESSION['email'] = $email;
			$_SESSION['gender'] = $gender;
			header("Location: register.php");
		}
		elseif ($gender == "") {
			$_SESSION['gender'] = "";
			$_SESSION['username'] = $username;
			$_SESSION['user'] = $name;
			$_SESSION['pass'] = $password;
			$_SESSION['email'] = $email;
			$_SESSION['address'] = $address;
			header("Location: register.php");
		}
		else{
			echo "<script> alert('You Have Been Registered ! Your Name is ".$name." and Your Username is ".$username." Please Log in Again ! Thankyou')</script>";
			echo "<script>setTimeout(\"location.href = 'home.php';\",1000);</script>";
			mysqli_query($con,"INSERT INTO userpasto VALUES (null, '$name', '$username', '$password', '$email', '$address', '$gender')");
			session_destroy();
		}
	}


//----------SIGN IN--------------------------------------------------------------------------
	if(isset($_POST['signinhome'])){
		$user=$_POST["username"];
		$pass=$_POST["password"];
		$result = mysqli_query($con, "SELECT * FROM userpasto");

		$true = false;
		while($row = mysqli_fetch_array($result)){
		if($row['username'] == $user && $row['password'] == $pass ){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$true = true;
			break;
		}
	}
		if($true){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$var_failed = '';
			header("Location: home.php");
		}
		else{
			$var_failed = 'home';
			$_SESSION['failed'] = $var_failed;
			header("Location: home.php");
		}
	}
	elseif(isset($_POST['signinpasta'])){
		$user=$_POST["username"];
		$pass=$_POST["password"];
		$result = mysqli_query($con, "SELECT * FROM userpasto");

		$true = false;
		while($row = mysqli_fetch_array($result)){
		if($row['username'] == $user && $row['password'] == $pass ){
			$true = true;
			break;
		}
	}
		if($true){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$var_failed = '';			
			header("Location: pasta.php");
		}
		else{
			$var_failed = 'pasta';
			$_SESSION['failed'] = $var_failed;
			header("Location: pasta.php");
		}
	}
	elseif(isset($_POST['signinrice'])){
		$user=$_POST["username"];
		$pass=$_POST["password"];
		$result = mysqli_query($con, "SELECT * FROM userpasto");

		$true = false;
		while($row = mysqli_fetch_array($result)){
		if($row['username'] == $user && $row['password'] == $pass ){
			$true = true;
			break;
		}
	}
		if($true){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$var_failed = '';			
			header("Location: rice.php");
		}
		else{
			$var_failed = 'rice';
			$_SESSION['failed'] = $var_failed;
			header("Location: rice.php");
		}
	}
		elseif(isset($_POST['signinother'])){
		$user=$_POST["username"];
		$pass=$_POST["password"];
		$result = mysqli_query($con, "SELECT * FROM userpasto");

		$true = false;
		while($row = mysqli_fetch_array($result)){
		if($row['username'] == $user && $row['password'] == $pass ){
			$true = true;
			break;
		}
	}
		if($true){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$var_failed = '';
			header("Location: other.php");
		}
		else{
			$var_failed = 'other';
			$_SESSION['failed'] = $var_failed;
			header("Location: other.php");
		}
	}
	elseif(isset($_POST['signinpackages'])){
		$user=$_POST["username"];
		$pass=$_POST["password"];
		$result = mysqli_query($con, "SELECT * FROM userpasto");

		$true = false;
		while($row = mysqli_fetch_array($result)){
		if($row['username'] == $user && $row['password'] == $pass ){
			$true = true;
			break;
		}
	}
		if($true){
			$_SESSION['id'] = $row['id'];
			$_SESSION['user'] = $row['name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['pass'] = $row['password'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['address'] = $row['address'];
			$_SESSION['gender'] = $row['gender'];
			$var_failed = '';			
			header("Location: packages.php");
		}
		else{
			$var_failed = 'packages';
			$_SESSION['failed'] = $var_failed;
			header("Location: packages.php");
		}	
	}
//---------Logout Tiap Page supaya stay-----------------------------------------------------
	if(isset($_POST['destroyhome'])){
		session_start();
		session_destroy();
		header("location: home.php");
	}
	elseif(isset($_POST['destroypasta'])){
		session_start();
		session_destroy();
		header("location: pasta.php");	
	}
	elseif(isset($_POST['destroyrice'])){
		session_start();
		session_destroy();
		header("location: rice.php");	
	}
	elseif(isset($_POST['destroyother'])){
		session_start();
		session_destroy();
		header("location: other.php");	
	}
	elseif(isset($_POST['destroypackages'])){
		session_start();
		session_destroy();
		header("location: packages.php");	
	}

//------------------Setting-------------------------------------------------------------------
	//==========Dari Form DropDown Setting masuk database terus masuk ke settings.php===============
	if(isset($_POST['settings'])){
		header("Location: settings.php");
	}

	//Kalau tekan tombol update di Settings.php
	if(isset($_POST['update'])){
		// echo $_POST['oldpassword'];
		// echo $_SESSION['pass'];		

		if($_SESSION['pass'] == $_POST['oldpassword']){
			$var_id = $_SESSION["id"];
			$var_user = $_POST["name"];
			$var_username = $_POST['username'];
			$var_password = $_POST["newpassword"];
			$var_email = $_POST['email'];
			$var_address = $_POST['address'];
			$var_gender = $_POST['gender'];
			
			$_SESSION['pass'] = $_POST['newpassword'];
			
			// echo $_SESSION['pass'].'<br>';
			// echo $var_id."<br>";
			// echo $var_user."<br>";
			// echo $var_username."<br>";
			// echo $var_password."<br>";
			// echo $var_email."<br>";
			// echo $var_address."<br>";
			// echo $var_gender."<br>";


			mysqli_query($con,"UPDATE userpasto SET name = '$var_user', username = '$var_username', password = '$var_password', email = '$var_email',address = '$var_address', gender = '$var_gender'  WHERE id = '$var_id' ");
			
			echo "<script> alert('Your Data Have Been Updated ! Your Name is ".$var_user." and Your Username is ".$var_username." Please Log in Again ! Thankyou')</script>";
			session_destroy();
			echo "<script>setTimeout(\"location.href = 'home.php';\",1000);</script>";
		}
		else if($_SESSION['pass'] != $_POST['oldpassword']){
			echo '<script> alert("Your Profile Update Was Canceled !") </script>';
			echo "<script>setTimeout(\"location.href = 'settings.php';\",1000);</script>";
		}
	}
?>